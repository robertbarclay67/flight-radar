# Flight Radar 4.0.9

A live flight tracker for the **Waveshare ESP32-S3-Touch-LCD-7** (7", 800×480, capacitive touch).

- **Radar or live map.** See aircraft around you on a radar sweep or on a street/satellite map, coloured by altitude with a legend. Ranges go from 1 to 250 miles (2 to 500 km).
- **Pinch and pan.** Pinch to zoom and drag to move any map. Dragging the live map shows the aircraft and airports of the new area.
- **Flight view.** Tap a plane for its route, airline, aircraft photo, altitude and speed. The map shows the path flown and the planned course, and the likely departure and arrival runways appear under each city.
- **Owner info.** Tap the tail number to see the registered owner (US aircraft, from the FAA registry). Private owners show city and state only.
- **Weather.** The **WX** button overlays rain radar on the map. Airport pages have a WX tab with the latest METAR and TAF.
- **Airports.** A built-in database of 9,000+ airports: runways, radio frequencies, address, phone, fuel, services and a photo. Ground maps for 64 major airports are built in.
- **Find anything.** Jump to major airports by region, or search by code, city or name.
- **Recent flights.** The last 25 flights you opened, from the menu.
- **Airport events and G-AIRMETs.** From the menu: ground stops, delay programs and closures at US airports (FAA), and IFR, turbulence and icing forecasts on a map of the US (aviationweather.gov).
- **Setup on the touchscreen.** Enter Wi-Fi and your ZIP or postal code on the display. No computer is needed after installing.

> This firmware only works on the Waveshare ESP32-S3-Touch-LCD-**7** (800×480, 16 MB flash, 8 MB PSRAM). It does not work on the 7B (1024×600) or other boards.

## What's new in 4.0.9

- **Flights open right on the map you're looking at.** Tap a plane and its flight opens at the same place and zoom, showing just that aircraft with its path and route, and the details in the side panel. **X** on the map goes back to all aircraft, exactly where you were.
- **INFO tab** tucks the flight details away for a full-width map while the plane stays selected, so you can follow it for as long as you like.
- **Gate numbers and taxiway letters in the flight view**, so you can follow a plane on the ground all the way to its gate. Planes on the ground open zoomed in close.
- **APPR on the main map** now switches to whichever plane you select, and turns off when you clear the selection.
## What's new in 4.0.8

- **A top bar on the main map**, like the apps: the aircraft count, **FIT**, **APPR** and **WX**, evenly spaced. With the aircraft list tucked away it adds AIRPORTS, the - / + range and the menu.
- **FIT** zooms the main map to the approach area of the airport you're at (or the nearest one). **APPR** follows the plane you've selected, the range set by its altitude. - / + adjust either; tap it again to go back to the view you had.
- **RADAR / STREET / SAT** moved into the left stack with ALL / AIRLINE / PRIVATE, all behind the VIEW tab.
- **Flight view:** APPR now stays on and re-zooms as the plane climbs or descends; tap it again to turn it off. - / + take over from FLT and APPR; FLT goes back to the whole route.
- **Recent flights** show each airline's logo.

## What's new in 4.0.7

- **Gate numbers and taxiway letters** on airport maps, from OpenStreetMap: taxiway letters as you zoom in, gate numbers one step further. Built in for the 64 major airports (over 10,000 gates); other airports download them on the first visit.
- **Folder tabs on the main screen.** VIEW (left) tucks the ALL / AIRLINE / PRIVATE buttons away; the altitude key stays. LIST (right) tucks the aircraft list away and the map or radar fills the whole screen, with a small - / + range control top right. Both remember how you left them.
- The aircraft count is now in the panel's header, next to FLIGHT RADAR.
- The widest range is now 250 miles (500 km). The 500-mile view used most of the board's memory; dropping it, and sharing map memory between screens, makes room for the full-width map with memory to spare.

## What's new in 4.0.6

- The flight view shows the time since takeoff and the estimated time left, between the distance flown and the distance to go (for example "6m | ~3h44"; ~ marks an estimate).
- **Airport events** (menu): ground stops, ground delay programs, departure and arrival delays, closures, de-icing and notices at US airports, live from the FAA's NAS status, most serious first. Tap an airport for its page.
- **G-AIRMETs** (menu): the FAA's graphical AIRMETs on a map of the US: SIERRA (IFR, mountain obscuration), TANGO (turbulence, wind shear, surface wind) and ZULU (icing, freezing level), now and every 3 hours to 12. Tap an area for its altitudes.
- The path flown now starts at the runway for flights that turn back over their airport after takeoff.

## What's new in 4.0.5

- ALL / AIRLINE / PRIVATE buttons on the left edge of the map filter the traffic, handy when an area is very busy.
- RADAR / STREET / SAT buttons: the view in use is lit, like FLT / APPR in the flight view.
- When a plane lands and receivers lose it at the airport, the flight view shows "Landed at LAX - at the gate" instead of "Signal lost".
- Airport pages show the airport's logo, and PHOTO (now on the INFO tab) shows a real photo of the airport rather than its logo.
- The path flown no longer includes the aircraft's previous flight.

## What's new in 4.0.4

- Real photos of the actual aircraft (from Planespotters.net, credited to the photographer) instead of a stock photo that could show another airline.
- When there's no photo of the aircraft, a stock photo in the manufacturer's own colours (Boeing, Airbus, Embraer...), labelled as such.
- Airline logos next to the airline name in the flight view.
- FLT (was FIT) shows the whole flight path, including the path actually flown; it's the view a flight opens with.
- APPR zooms in according to the aircraft's altitude; + and - adjust from there.
- Flights across the Pacific (for example Taipei - Los Angeles) are now drawn across the date line instead of the long way round the world.

## What's fixed in 4.0.3

- Fixed the board restarting on wide views (250 and 500 miles) over busy areas: reading thousands of aircraft at once took long enough to trip the watchdog.
- Fixed memory slowly running out while browsing maps, which caused "Network error" messages and slow or blank maps.
- Wide views now show aircraft across the whole area. When there are more than 600, an even sample is shown, labelled like "600 of 1,900 aircraft".
- Aircraft downloads are compressed (about 5 times smaller), so wide views update 2 to 3 times faster, and maps no longer wait for them to finish.

## What's fixed in 4.0.2

- Fewer "Network error" messages: an aircraft download that breaks off is retried, a single missed update no longer shows an error, and downloads use memory more carefully.
- Tap the status box (top left) while it shows a problem to retry straight away; it also reconnects Wi-Fi if that has dropped.
- Faster live map zooming: the map views for the next range in and out are loaded ahead of time, including the steps that skip zoom levels.

## What's fixed in 4.0.1

- Flight view: origin and destination were sometimes backwards for flights whose flight number is used in both directions, such as out-and-back trips (PHX-LAX-PHX). The aircraft's heading now decides the direction, and a schedule that doesn't match where the plane is going shows "Route not available" instead of a wrong route.

## Install

### Option 1: Browser installer (easiest)

1. Host this folder somewhere that serves **https**, such as GitHub Pages. For local testing you can run `python -m http.server` in this folder and open `http://localhost:8000`.
2. Open `index.html` in **Chrome or Edge** on a computer.
3. Plug the display in using the port labelled **USB**, click **Connect and install**, and choose **Erase device**.

The image is 6.8 MB, so installing takes 2–3 minutes. Press **RESET** afterwards if the screen stays dark.

### Option 2: esptool (command line)

```
pip install esptool
esptool --chip esp32s3 --port COM7 erase-flash
esptool --chip esp32s3 --port COM7 --baud 460800 write-flash 0x0 flight-radar-v4.0.9-waveshare-esp32s3-lcd7.bin
```

Replace `COM7` with your port (on Mac/Linux, for example `/dev/ttyACM0`).

If the board isn't detected or the upload stops partway, hold **BOOT**, tap **RESET**, release **BOOT**, and try again. Press **RESET** when it's done.

Upgrading from 3.0: erasing is recommended, since 4.0 uses a new flash layout. You'll go through the setup again.

## First-time setup

The display walks you through three steps:

1. **Wi-Fi:** pick your network from the list and type the password on the on-screen keyboard. The ESP32 only supports **2.4 GHz** Wi-Fi.
2. **Country and postal code:** used to centre the radar on your area.
3. **Confirm:** check the location and units. Imperial is the default in the USA and metric elsewhere; tap to change.

To change Wi-Fi or your home location later, open the **menu (☰)** and choose **Change Wi-Fi or home location**.

## Using it

| Where | What it does |
|---|---|
| **RADAR / STREET / SAT** (bottom of the map) | Radar sweep, street map or satellite; the one in use is lit |
| **ALL / AIRLINE / PRIVATE** (left edge) | Show every aircraft, only airline flights, or only private and other traffic |
| **VIEW / LIST tabs** | Tuck the left buttons or the right panel away for more map |
| **FIT / APPR** (top bar) | Zoom to the airport's approach / follow the selected plane; tap again for the view before |
| **☰** (top right) | Menu: recent flights, go to an airport, airport events, G-AIRMETs, units, change Wi-Fi or location |
| **AIRPORTS** | Major airports by region, or search by code, city or name |
| **INFO / HOME** | When viewing another airport: its info page, or back home |
| **− / +** | Change the range; they wrap around between 1 and 250 miles |
| Pinch / drag | Zoom and pan the map |
| Aircraft list | Scroll by distance band, or choose ALL |
| Tap a plane or list row | Show its details; then **FLIGHT VIEW >** for route, photo and map |
| Tap an airport | Airport page with INFO, RADIO, SERVICES and WX tabs |
| **+ − FLT APPR** (flight view) | Zoom; FLT shows the whole flight path; APPR zooms in close according to altitude |
| **+ − FIT** (airport page) | Zoom; FIT shows the whole airport |
| **STREET / SAT** (flight and airport maps) | Street map or satellite imagery |
| **WX** | Rain radar overlay |
| Flight view: tail number | Registered owner info |
| Flight view: origin/destination code | Open that airport's page |

## Privacy

Your Wi-Fi password and location are stored only on the device, in its flash memory. The display sends the approximate location of the area you are viewing (your postal code's centre, or the airport or map area you picked) to the aircraft, map and weather services. It does not send your Wi-Fi details anywhere.

## Data sources and credits

All services are free and need no account. Please keep use personal and non-commercial.

| Data | Source |
|---|---|
| Aircraft positions | [adsb.lol](https://adsb.lol), [adsb.fi](https://adsb.fi) |
| Flight routes | [adsb.im](https://adsb.im) (route set), [adsbdb.com](https://www.adsbdb.com) (airline names) |
| Flight path history | [The OpenSky Network](https://opensky-network.org) |
| Aircraft owners | FAA Aircraft Registry |
| Maps and satellite imagery | Esri World Street Map / World Imagery |
| Rain radar | [RainViewer](https://www.rainviewer.com) |
| METAR / TAF | [aviationweather.gov](https://aviationweather.gov) (NOAA) |
| Airports, runways, frequencies | [OurAirports](https://ourairports.com/data/) (public domain), FAA NASR |
| Ground maps and airport contacts | © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors |
| Postal code lookup | [Zippopotam.us](https://zippopotam.us), OpenStreetMap Nominatim |
| Aircraft and airport photos | Wikipedia / Wikimedia Commons |

**Not for navigation.** Routes, runways, frequencies, weather, fuel prices and owner data come from public and community sources and may be wrong or out of date.

## Troubleshooting

- **Stuck on "Connecting to Wi-Fi":** check that the network is 2.4 GHz, then use ☰ → *Change Wi-Fi or home location*.
- **"Route not available":** common for private, training and military flights, which have no published schedule.
- **No ground map for a small airfield:** it may not be mapped in OpenStreetMap yet. Ground maps for airports outside the built-in 64 are downloaded once and then cached.
- **Screen dark after installing:** press **RESET** on the board.
- **Start completely fresh:** reinstall with *Erase device* ticked, or run `esptool erase-flash`.
