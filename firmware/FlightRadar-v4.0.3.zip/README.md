# Flight Radar 4.0.3

A live flight tracker for the **Waveshare ESP32-S3-Touch-LCD-7** (7", 800×480, capacitive touch).

- **Radar or live map.** See aircraft around you on a radar sweep or on a street/satellite map, coloured by altitude with a legend. Ranges go from 1 to 500 miles (2 to 1,000 km).
- **Pinch and pan.** Pinch to zoom and drag to move any map. Dragging the live map shows the aircraft and airports of the new area.
- **Flight view.** Tap a plane for its route, airline, aircraft photo, altitude and speed. The map shows the path flown and the planned course, and the likely departure and arrival runways appear under each city.
- **Owner info.** Tap the tail number to see the registered owner (US aircraft, from the FAA registry). Private owners show city and state only.
- **Weather.** The **WX** button overlays rain radar on the map. Airport pages have a WX tab with the latest METAR and TAF.
- **Airports.** A built-in database of 9,000+ airports: runways, radio frequencies, address, phone, fuel, services and a photo. Ground maps for 64 major airports are built in.
- **Find anything.** Jump to major airports by region, or search by code, city or name.
- **Recent flights.** The last 25 flights you opened, from the menu.
- **Setup on the touchscreen.** Enter Wi-Fi and your ZIP or postal code on the display. No computer is needed after installing.

> This firmware only works on the Waveshare ESP32-S3-Touch-LCD-**7** (800×480, 16 MB flash, 8 MB PSRAM). It does not work on the 7B (1024×600) or other boards.

## What's fixed in 4.0.3

- Fixed the board restarting on wide views (250 and 500 miles) over busy areas: reading thousands of aircraft at once took long enough to trip the watchdog.
- Fixed memory slowly running out while browsing maps, which caused "Network error" messages and slow or blank maps.
- Wide views now show aircraft across the whole area. When there are more than 600, an even sample is shown, labelled like "600 of 1,900 aircraft".
- Aircraft downloads are compressed (about 5 times smaller), so wide views update 2 to 3 times faster, and maps no longer wait for them to finish.

## What's fixed in 4.0.2

- Fewer "Network error" messages: an aircraft download that breaks off is retried, a single missed update no longer shows an error, and downloads use memory more carefully.
- Tap the status box (top left) while it shows a problem to retry straight away; it also reconnects Wi-Fi if that has dropped.
- Faster live map zooming: the map views for the next range in and out are loaded ahead of time, including the steps that skip zoom levels.

## What's fixed in 4.0.1

- Flight view: origin and destination were sometimes backwards for flights whose flight number is used in both directions, such as out-and-back trips (PHX-LAX-PHX). The aircraft's heading now decides the direction, and a schedule that doesn't match where the plane is going shows "Route not available" instead of a wrong route.

## Install

### Option 1: Browser installer (easiest)

1. Host this folder somewhere that serves **https**, such as GitHub Pages. For local testing you can run `python -m http.server` in this folder and open `http://localhost:8000`.
2. Open `index.html` in **Chrome or Edge** on a computer.
3. Plug the display in using the port labelled **USB**, click **Connect and install**, and choose **Erase device**.

The image is 6.8 MB, so installing takes 2–3 minutes. Press **RESET** afterwards if the screen stays dark.

### Option 2: esptool (command line)

```
pip install esptool
esptool --chip esp32s3 --port COM7 erase-flash
esptool --chip esp32s3 --port COM7 --baud 460800 write-flash 0x0 flight-radar-v4.0.3-waveshare-esp32s3-lcd7.bin
```

Replace `COM7` with your port (on Mac/Linux, for example `/dev/ttyACM0`).

If the board isn't detected or the upload stops partway, hold **BOOT**, tap **RESET**, release **BOOT**, and try again. Press **RESET** when it's done.

Upgrading from 3.0: erasing is recommended, since 4.0 uses a new flash layout. You'll go through the setup again.

## First-time setup

The display walks you through three steps:

1. **Wi-Fi:** pick your network from the list and type the password on the on-screen keyboard. The ESP32 only supports **2.4 GHz** Wi-Fi.
2. **Country and postal code:** used to centre the radar on your area.
3. **Confirm:** check the location and units. Imperial is the default in the USA and metric elsewhere; tap to change.

To change Wi-Fi or your home location later, open the **menu (☰)** and choose **Change Wi-Fi or home location**.

## Using it

| Where | What it does |
|---|---|
| **MAP / RADAR** (top right) | Switch between the radar sweep and the live map |
| **☰** (top right) | Menu: recent flights, units, change Wi-Fi or location |
| **AIRPORTS** | Major airports by region, or search by code, city or name |
| **INFO / HOME** | When viewing another airport: its info page, or back home |
| **− / +** | Change the range; they wrap around between 1 and 500 miles |
| Pinch / drag | Zoom and pan the map |
| Aircraft list | Scroll by distance band, or choose ALL |
| Tap a plane or list row | Show its details; then **FLIGHT VIEW >** for route, photo and map |
| Tap an airport | Airport page with INFO, RADIO, SERVICES and WX tabs |
| **+ − FIT APPR** (flight and airport maps) | Zoom, fit the whole route, or a close-up approach view |
| **SATELLITE / STREET MAP** | Switch imagery |
| **WX** | Rain radar overlay |
| Flight view: tail number | Registered owner info |
| Flight view: origin/destination code | Open that airport's page |

## Privacy

Your Wi-Fi password and location are stored only on the device, in its flash memory. The display sends the approximate location of the area you are viewing (your postal code's centre, or the airport or map area you picked) to the aircraft, map and weather services. It does not send your Wi-Fi details anywhere.

## Data sources and credits

All services are free and need no account. Please keep use personal and non-commercial.

| Data | Source |
|---|---|
| Aircraft positions | [adsb.lol](https://adsb.lol), [adsb.fi](https://adsb.fi) |
| Flight routes | [adsb.im](https://adsb.im) (route set), [adsbdb.com](https://www.adsbdb.com) (airline names) |
| Flight path history | [The OpenSky Network](https://opensky-network.org) |
| Aircraft owners | FAA Aircraft Registry |
| Maps and satellite imagery | Esri World Street Map / World Imagery |
| Rain radar | [RainViewer](https://www.rainviewer.com) |
| METAR / TAF | [aviationweather.gov](https://aviationweather.gov) (NOAA) |
| Airports, runways, frequencies | [OurAirports](https://ourairports.com/data/) (public domain), FAA NASR |
| Ground maps and airport contacts | © [OpenStreetMap](https://www.openstreetmap.org/copyright) contributors |
| Postal code lookup | [Zippopotam.us](https://zippopotam.us), OpenStreetMap Nominatim |
| Aircraft and airport photos | Wikipedia / Wikimedia Commons |

**Not for navigation.** Routes, runways, frequencies, weather, fuel prices and owner data come from public and community sources and may be wrong or out of date.

## Troubleshooting

- **Stuck on "Connecting to Wi-Fi":** check that the network is 2.4 GHz, then use ☰ → *Change Wi-Fi or home location*.
- **"Route not available":** common for private, training and military flights, which have no published schedule.
- **No ground map for a small airfield:** it may not be mapped in OpenStreetMap yet. Ground maps for airports outside the built-in 64 are downloaded once and then cached.
- **Screen dark after installing:** press **RESET** on the board.
- **Start completely fresh:** reinstall with *Erase device* ticked, or run `esptool erase-flash`.
